//Operators
 /* Operators are special symbols or keywords that perform operations on variables and values. They are used to manipulate data and perform calculations. */

/*
1.Arithmetic Operators - to perform basic mathematical operations.
2.Assignment Operators - to assign values to variables.
3.Comparison Operators - to compare two values.
4.Logical Operators - to combine multiple conditions. 
5.String Operators - to join strings or combine strings with other data types.
*/

//1.Arithmetic Operators - Arithmetic operators are used to perform basic mathematical operations
//1.1)Addition (+)

console.log('Arithmetic Operators');
let sum = 5 + 3;
console.log('Addition:', sum);

//1.2)Subtraction (-)

let difference = 10 - 2;
console.log('Subtraction:', difference);

//1.3)Multiplication (*)

let product = 2*2;
console.log('Multiplication:', product);

//1.4)Division (/)

let x = 12/2;
console.log('Division:', x);

//1.5)Modulus (%)

let remainder = 10 % 3;
console.log('Modulus', remainder);

//1.6)Exponentiation (**)

let power = 2**3;
console.log("Exponentiation:", power);

//1.7)Increment (++)

let CountOne = 5;
CountOne++;
CountOne++;
console.log('Increment:', CountOne);

//1.8)Decrement (--)

let CountTwo = 5;
CountTwo--;
CountTwo--;
console.log('Increment:', CountTwo);

//2.Assignment Operators - Assignment operators are used to assign values to variables.
//2.1)Assignment (=)

console.log('Assignment Operators');
let z = 10;
console.log('Assignment:',z);

//2.2)Addition Assignment (+=)

z += 20;
console.log('Addition Assignment:', z);

//2.3)Subtraction Assignment (-=):

z -= 2;
console.log('Subtraction Assignment:', z);

//2.4)Multiplication Assignment (*=):

z *= 2;
console.log('Multiplication Assignment:', z);

//2.5)Division Assignment (/=):

z /= 2;
console.log('Division Assignment:', z);

//2.6)Modulus Assignment (%=):

z %= 2;
console.log('Modulus Assignment:', z);

//2.7)Exponentiation Assignment (**=)

let y = 2;
y **= 3;
console.log('Exponentiation Assignment:', y);

//3.Comparison Operators - Comparison operators are used to compare two values.

console.log('Comparison Operators');

//3.1)Equal (==)

console.log("Equal 5 =='5':", 5 == '5');

console.log("Equal 5 =='5':", 5 == '5'); //(type coerction)

//3.2)Strict Equal (===)

console.log("Equal 5 ==='5':", 5 === '5'); //false (no type coerction)

//3.4)Not Equal (!=)

console.log("Not Equal 4 !='5':", 4 != '5');

//3.5)Strict Not Equal (!==)

console.log("Not Equal 4 !=='5':", 4 !== '5');

//3.6)Greater Than (>)

console.log("Greater Than 10>5:", 10>5);

//3.7)Less Than (<)

console.log("Less Than 5<10:", 5<10);

//3.8)Greater Than or Equal (>=)

console.log("Greater Than or Equal  10>=10:", 10>=10);

//3.9)Less Than or Equal (<=)

console.log("Less Than or Equal  10<=10:", 5<=10);

//4.Logical Operators - Logical operators are used to combine multiple conditions.

console.log('Logical Operators');

//4.1)Logical AND (&&)

console.log('AND', true && false);
console.log('AND', false && true);
console.log('AND', true && true);
console.log('AND', false && false);

//4.2)Logical OR (||)

console.log('OR', true || false);
console.log('OR', false || true);
console.log('OR', true || true);
console.log('OR', false || false);

//4.3)Logical NOT (!)

console.log('NOT', !true);
console.log('NOT', !false);

//Example

let haveIdProof = false;
let isAdult = true;

if(haveIdProof && isAdult){
    console.log('You are allowed to entry party');
}else
{
    console.log('You are not allowed to entry party');
}


if(haveIdProof || isAdult){
    console.log('You are allowed to entry party');
}else
{
    console.log('You are not allowed to entry party');
}

// String Operators

console.log('String Operators');

console.log('Hello world');

//String concatenation

let str = 'Hello'+ ' '+'world';
console.log(str);

str+= 'How are you?';
console.log(str);

//String with Different Quotes:

console.log("I'm getting 'better'day by day");

let message = "I'm "+'getting'+ "'better'"+'day by day';
console.log(message);

console.log('I\'m getting "better" day by day');

let userDetails = {
    id: 1,
    name: 'Jane',
};

//Concatenation with Object Properties:

console.log('Welcome '+ userDetails.name + ' Your id is ' + userDetails.id);

//Template literal

console.log(`welcome ${userDetails.name} Your id is ${userDetails.id}`);

//Order Prcedence

console.log('Operators Order Precedence');
console.log(2+4*3); 
console.log((2+4)*3);

// New Examples with - and /

console.log(10 - 2 / 2);
console.log((10 - 2) / 2);

// Additional Combined Example

console.log((8 / 2) * (2 + 2));
