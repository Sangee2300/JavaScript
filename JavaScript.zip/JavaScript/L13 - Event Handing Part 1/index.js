const button = document.getElementById('button');

console.log(button);
button .addEventListener('click', ()=> {
    console.log('Button-Clicked');
});

button .addEventListener('click', ()=> {
    alert('Button-Clicked');
});

button.addEventListener('mouseover',() => {
    button.classList.add('buttonover');
} );


button.addEventListener('mouseout',() => {
    button.classList.add('buttonover');
} );

/*document.addEventListener('keydown',(event) => {
    if (event.key === 'Enter') {
        alert('Enter Key is pressed!');
    }
});*/

/*document.addEventListener('keypress',(event) => {
    if (event.key === 'Enter') {
        alert('Enter Key is pressed!');
    }
}); */

document.addEventListener('keyUp',(event) => {
    if (event.key === 'Enter') {
        alert('Enter Key is pressed!');
    }
});

document.addEventListener('keydown',(event)=>{
    if (event.shiftKey) {
        alert('Shift key pressed!');
    }
    if (event.ctrlKey) {
        alert('Shift key pressed!');
    }

    if(event.key >= 'a' && event.key <= 'z') {
        alert("Alphabetical key '${event.key}' pressed!");
    }

    if(event.key >= '1' && event.key <= '0') {
        alert("Number key '${event.key}' pressed!");
    }


});