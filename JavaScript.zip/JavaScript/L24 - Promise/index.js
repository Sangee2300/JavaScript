//Promise
/* 
A promise will either resolve with a value or reject with an error
SYNTAX
let promise = new Promise((resolve,reject)=>{
    if(true){
         resolve()
    }else{
         reject()
    }
}) */


    /** 

    let promise = new Promise((resolve,reject)=>{
        let data = 5;
        if(typeof data === 'number'){
             resolve('Success');
        }else{
             reject('Failed');
        }
    });

promise
.then((result)=>{
    console.log(`On Resolve:${result}`);
})
.catch((error)=>{
    console.log('On Reject:${error}') 
});

function fetchData(){
    return new Promise((resolve,reject)=>{
        console.log('fetching Data....');
        setTimeout(()=>{
            const data = {id:1,name:"John Doe"}
            const randomValue = Math.random();
            console.log(`Random Value ${randomValue}`);
            const success = randomValue >0.2;
            if(success){
                resolve(data);
            }else{
                reject('Failed to fetch data');
            }
        },1000)
    })
}
fetchData().then((result)=>{
    console.log('Data fetched:',result);
}).catch((error)=>{
    console.log('Error:',error);
});

*/

let promise1 = new Promise((resolve) => {
    setTimeout(() => {
        resolve('Promise 1 Resolved');
    }, 2000);
});

let promise2 = new Promise((resolve) => {
    setTimeout(() => {
        resolve('Promise 2 Resolved');
    }, 1000);
});

let promise3 = new Promise((resolve) => {
    setTimeout(() => {
        resolve('Promise 3 Resolved');
    }, 3000);
});

promise1.then((result) => {
    console.log(result);
});

promise2.then((result) => {
    console.log(result);
});

promise3.then((result) => {
    console.log(result);
});
promise1.all([promise1,promise2,promise3]).then((result)=>{
    console.log('All Promise resolved',result);
}).catch((error)=>{
    console.log(error);
});

promise1.race([promise1,promise2,promise3]).then((result)=>{
    console.log('All Promise resolved',result);
}).catch((error)=>{
    console.log(error);
});




