//Error Handling 
/* Error handling in js is a way to manage and respond to errors that occur during the execution of your code. It helps ensure that your program can handle unexcepted situations gracefully and provide usefulfeedback to users or developers*/

/* 
SYNTAX 
try { 
//Code Block
}catch(error){
//code Block
}finally{
//code that runs no matter what 
}*/

class Bank {
    users = [
        { accountNo: 44301, balance:12000, userName:'Abi', password:'1234' },
        { accountNo: 44302, balance:12350, userName:'Anu', password:'5678' },
        { accountNo: 44303, balance:14000, userName:'Ali', password:'134' },
    ];
    getBalanceWithOutErrorHandling(accountNo) {
        const result = this.users.find((x) => x.accountNo === accountNo);
        console.log(`Balance:${result.balance},Account Holder:${result.userName}`);
    }
    getBalance(accountNo, password) {
        try{
            const result = this.users.find((x) => x.accountNo === accountNo);
            if (result) {
                const isValidPassword = result.password === password;

                if (isValidPassword) {
                    console.log(
                        `Balance:${result.balance},Account Holder:${result.userName}`
                    );

                    return `Balance:${result.balance},Account Holder:${result.userName}`;
                }
            } else {
                throw `Invalid Account No ${accountNo}` ;
            }

        } catch (error) {
            console.log(error);
        return error;
    } finally{
            console.log('process is completed');

        }
        
    }
    
}

let stateBank = new Bank();

console.log(stateBank.users);
stateBank.getBalance(443305,'1234');
//stateBank.getBalanceWithOutErrorHandling(443301);
//stateBank.getBalanceWithOutErrorHandling(443303);



const formElement = document.getElementById('formData');
const displayMessage = document.getElementById('displayMessage');

formElement.addEventListener('submit',function (){
    event.preventDefault();
    const formData = new FormData(this);
    const request ={ accountNo: null, password:''};

    formData.forEach((value, key) => {
        request[key] = value;

    });
    let indianBank = new Bank();
    const response = indianBank.getBalance (
        Number(request.accountNo),
        request.password
    );
    displayMessage.innerHTML = response;
    formElement.reset();
});