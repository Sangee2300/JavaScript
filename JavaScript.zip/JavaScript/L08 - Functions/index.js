// Functions
/* Functions are reusable blocks of code designed to perform a specific task. They help in organizing code, avoiding repetition, and improving readability and maintainability. */

// Functions are pieces of code that we can reuse again and again in our code
// Types of Functions
/* 1. Function Declaration 
2. function Expression
3.Arrow Function
4. Anonymous Functions (On Arrays) */



// Function Declaration - JavaScript Hoisting
/* A function declaration defines a named function.It's hoisted,
 meaning you can call it before it's defined. */

 //  Function Syntax 

/* function FunctionName() {
       //Block of code 
}
FunctionName()//Calling Function */

console.log("We are developers, We love to code");
console.log("We are developers, We love to code");
console.log("We are developers, We love to code");
console.log("We are developers, We love to code");
console.log("We are developers, We love to code");

function displayMessage(){
       console.log('We are developers, We love to code');
       let x = 10;
       let y =30;
       console.log(x+y);
}

// Calling the function

displayMessage();

// Function Parameters and Arguments
/*Functions can take parameters, which act as placeholders for the values 
that will be passed to the function.The passing value is called an argument.*/

function greet(userName){
       console.log('Good Morning,'+userName+'!');
}

//argument
greet('Abi');
greet('Anu');

function greetUser(firstName,lastName) {
       console.log(`Hello,${firstName} ${lastName}`);
}

greetUser('Mani','maran');
greetUser('Maha','lakshmi');

function math(x,y,z){
       console.log(x+y+z);
}
math(10,20,30);

// Default Parameter

function printer(color){
       console.log(`print document in ${color} color`);
}

printer('Blue');
printer();
printer('Red');


// Function with Return Type

function add(a,b){
       return a+b;
}

let sum = add(50,30);
console.log(sum);
///////////////////////////////////////////////////////////////////////

// Function Expression
/* A function expression defines a function inside an expression.
It's not hoisted, so you can't call it before it's defined.*/

const morning = function(){
       console.log('Good morning Everyone!');
};
morning();

// With Argument

const morningWithName = function(name){
       console.log(`Good morning ${name}`);
};
morningWithName('Abi');

// Function Expression with Return Type

const multiply = function (a,b) {
       return a*b;
};
const product = multiply(4,7);


///////////////////////////////////////////////////////////////////////

// Arrow Function
// Arrow functions provide a concise syntax and do not bind their own 'this'. They are not hoisted.
// Function Syntax
const FunctionName = ()=>{
       //code block
}
FunctionName() //calling function

const evening = () => {
       console.log('Good Evening Everyone!');
};

evening();

// With Argument

const eveningWithName = (name) => {
       console.log('Good Evening'+ name + '!');
};

eveningWithName('Abi');

// Arrow Function with Return Type

const subtract = (a,b) => {
       return a=b;
};
console.log(subtract(10,6));

// Shorter Way

const subtract1 = (a,b)=>a-b;
console.log(subtract1(10,6));

//Function Calling Other Function

function welcomeShopper(name){
       console.log(`Welcome,${name}! Enjoy your shopping experinence.`);
}

function main(name) {
       let shopperName = name;
       welcomeShopper(shopperName);
}

main('Anu');


//Anonymous Functions: Later on Course on Arrays

setTimeout(()=>{
       console.log('Anoymous functions executed');
},2000);

/**
Scope of variables will on functions and loops
var: Function scoped.
let: Block scoped.
const: Block scoped.
 */

function demo(){
       var a = 20;
       console.log(a);
       if(true){
              var x = 'var';
              let y = 'let';
              const z = 'const';

              console.log(x);
              console.log(y);
              console.log(z);
       }
       console.log(x);
       //console.log(y);
       //console.log(z);
}
demo();
//console.log(a);