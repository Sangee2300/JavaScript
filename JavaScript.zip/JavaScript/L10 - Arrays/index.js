/*
An array is a data structure that can hold multiple values at once. 
These values can be of any type, including numbers, strings, objects, or even other arrays.
Arrays in JavaScript are zero-indexed, meaning the first element is at index 0.

Array syntax

  const ArrayName = [Item1,Item2,Item3];
*/

// Using square brackets

let fruits = ['Apple','Orange','Banana'];
console.log(fruits);

// Accessing Array Elements:
console.log(fruits[0]);
console.log(fruits[1]);
console.log(fruits[2]);
console.log(fruits[3]);

// Change Value in Array

fruits[1] = 'Cherry';
console.log(fruits);

/*
Using for loop to print array with hard-coded condition 
it will create issue if condition is like i < 5
*/

debugger;
for (let i=0;i<3;i++){
    console.log(fruits[i]);
}

/* 
To avoid hard-coded condition switch to array methods
*/
// We can use array length

console.log(fruits.length);

for (let i=0;i<fruits.length;i++){
    console.log(fruits[i]);
}

// More Array Methods

let box =['Books', 'Toys', 'pen'];
console.log(box);

/* 
Add element to array
Adds one or more elements to the end of an array 
and returns the new length of the array.
*/

let push =('Diary');
console.log(box);

/*
Remove element from array
Removes the last element from an array and returns that element.
*/

box.pop();
console.log(box);

/*
Adds one or more elements to the beginning of an array and returns the new length of the array.
*/

box.unshift('Map');
console.log(box);

/*
Removes the first element from an array and returns that element.
*/

box.shift();
console.log(box);
 
// Anonymous Functions

box.forEach(function (x,index){
    console.log(x, index);
});

box.forEach((x, index)=>{
    console.log(x, index);
});

// Combining Arrays

let containerOne = ['TV', 'Laptop'];
let containerTwo = ['PlayStation', 'Table'];

console.log(containerOne);
console.log(containerTwo);

let containter = containerOne.concat(containerTwo);

// Finding an Element Index, If not found it will return -1

let searchValue = 'TV';
let index = containter.indexOf(searchValue);
console.log(index);

if (index >= 0) {
    console.log(`Index of ${searchValue} is ${index}`);
}
else {
    console.log('What you are searching for is not available in the container');
}

// Array with mixed data types

let mixedData = [
    10,
    3.4,
    'HomeLader',
    'StarLight',
    true,
    false,
    undefined,
    null
];

console.log(mixedData);
console.log(mixedData.includes('HomeLader'));
console.log(mixedData.includes(48));
console.log(mixedData.includes(null));

let numbers = [20,54,78,43,24];
console.log(numbers);

// Array of Employee Objects

let Employees =[
    {id: 1, name: 'Abi', age:30},
    {id: 2, name: 'Athi', age:25},
    {id: 3, name: 'Anu', age:35},
];

console.log(Employees);

Employees.forEach((employees)=>{
    console.log(`Employee Id: ${Employees.id}`);
    console.log(`Employee Name: ${Employees.name}`);
    console.log(`Employee Age: ${Employees.age}`);
    console.log('....')
});

//Fliters

let employees = Employees.find((x) => x.id ===3);
console.log(employees);

let x = Employees.filter((x)=>x.age > 30);
console.log(x);

// Map

let y = Employees.map((Employees) => {
    console.log(
        `Name:${employees.name}, DOB:${new Date().getFullYear() - employees.age}`
    );
});
