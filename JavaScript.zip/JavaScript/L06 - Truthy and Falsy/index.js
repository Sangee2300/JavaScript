// Truthy and Falsy Values

/* In JS, truthy and falsy values are used to determine whether a value evaluates to true or false in a boolean context. This concept is crucial for controlling the flow of yourprogram using conditions like if statement */

console.log('Truthy and Falsy Values');

// Falsy Values:

console.log(Boolean(0));
console.log(Boolean(undefined));
console.log(Boolean(''));
console.log(Boolean(null));
console.log(Boolean(false));
console.log(Boolean());

// Truthy Values:

console.log(Boolean(1));
console.log(Boolean(-1));
console.log(Boolean("Hello"));
console.log(Boolean({}));
console.log(Boolean([]));
console.log(Boolean(function() {}));

let cash = 260;
if (cash) {
    if (cash > 100) {
        console.log("You can buy burger with drink");
    }
    else {
        console.log("You can only buy burger");
    }
}
else {
    console.log("You don't have enough money for shopping");
}

let age;
console.log(age);
if (age) {
    console.log("Age is defined");
}
else {
    console.log("Age is undefined");
}

let hasPermission = true;
if (hasPermission) {
    console.log("You have permission");
}
else{
    console.log("You do n't have permission");
}