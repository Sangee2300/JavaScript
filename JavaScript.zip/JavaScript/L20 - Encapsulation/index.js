class BankAccount {
    #balance; // private field

    constructor(initialBalance) {
        this.#balance = initialBalance;
    }

    deposit(amount) {
        if (amount > 0) {
            this.#balance += amount; // Corrected the operator to +=
            console.log(`Deposited ${amount}. New Balance: ${this.#balance}`); // Added space for better readability
        } else {
            console.log('Invalid deposit amount');
        }
    }

    withdraw(amount) { // Correct placement of the withdraw method
        if (amount > 0 && amount <= this.#balance) {
            this.#balance -= amount;
            console.log(`Withdrawn ${amount}. New Balance: ${this.#balance}`); // Added space for better readability
        } else {
            console.log('Insufficient funds or invalid amount.');
        }
    }
    getBalance() {
        return this.#balance;
    }
    
}

let savingAccount =new BankAccount(1000);

savingAccount.deposit(500);
savingAccount.withdraw(200);

savingAccount.withdraw(3000);
savingAccount.deposit(1000);

//savingAccount.#Balance = 10000;

console.log(savingAccount.getBalance());
