// Higher Order & Call Back Function 
/* Functions that take other functions as arguments or retun then as results. */

function startEngine() {
    return 'Engine is started!';
}
console.log(startEngine());

function drive(driveName, engine) {
    const message = engine(); //Callback function

    console.log(`${message} by ${driveName}`);
}
drive('Alex',startEngine);

//Pure function

function add(a,b) {
    return a+b;
}

console.log(add(2,3));
console.log(add(2,3));
console.log(add(2,3));

//Impure function

let counter = 0;
function increment(value) {
    counter += value;
    return counter;
}

console.log(increment(2));
console.log(increment(2));
console.log(increment(2));

