class person{
    constructor(firstName,lastName,dob,phoneNumber,isEmployed){
        this.firstName = firstName;
        this.lastName = lastName;
        this.dob = dob;
        this.phoneNumber = phoneNumber;
        this.isEmployed = isEmployed;

    }
    getDetails() {
        const age = new Date().getFullYear() - parseInt(this.dob); // Parse dob as an integer
        console.log(`${this.firstName} ${this.lastName} is ${age} years old & contact no is ${this.phoneNumber}`);
    }
    getEmploymentStatus() {
        console.log(`${this.firstName} is ${this.isEmployed ? 'employed' : 'unemployed'}`);
    }
}

class Employee extends person {
    constructor(
        firstName,
        lastName,
        dob,
        phoneNumber,
        isEmployed,
        jobTitle,
        company
    ){
        super(firstName,lastName,dob,phoneNumber,isEmployed);
        this.jobTitle = jobTitle;
        this.company = company;
    }
    getJobDetails() {
        console.log(
            `${this.firstName} ${this.lastName} work as a ${this.jobTitle} at ${this.company}`
        );
    }
}
let employee1 = new Employee(
    'Arun',
    'kumar',
    1990,
    9087654321,
    true,
    'Software Developer',
    'Tech Corp'

);

employee1.getDetails();
employee1.getEmploymentStatus();
employee1.getDetails();

let employee2 = new Employee(
    'priya',
    'Dharsini',
    1995,
    9249654321,
    false,
    'Web Developer',
    'Innovate ltd'

);

employee2.getDetails();
employee2.getEmploymentStatus();
employee2.getDetails();
