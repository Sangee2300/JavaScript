/* Type conversion and type coeracion are processes in programming that change a value from one data type to another. this is often necessary because different operations require values to be in specific formats. */

//Type Conversion (Manually)
/*Type conversion (also known as type casting) is when you explicitly convert a value from one type to another. JavaScript provides several functions for this purpose.*/

// Type Conversion
console.log('Type Conversion');

// String to Number

let strNum = '123';
let num = Number(strNum);
console.log(num);
console.log(typeof num);

// Number to String

let numStr = 123;
let str = String(numStr);
console.log(str);
console.log(typeof str);

// Boolean to String

let bool = true;
let strBool = String(bool);
console.log(strBool);
console.log(typeof strBool);

// String to Boolean

let strTrue = 'true';
let strFalse = 'false';
let booltrue = Boolean(strTrue);
let boolFalse = Boolean(strFalse);
console.log(booltrue);
console.log(boolFalse); //True (any non-Empty string is true in Boolean context)

// Parsing integers and floats

let floatStr = '123.45';
let intNum = parseInt(floatStr);
console.log(intNum);
//let floatNum = parsefloat(floatStr);
//9console.log(floatNum);

//Type Coercion
/*Type coercion is when JavaScript automatically converts a value from one type to another during an operation. This often happens with equality checks and arithmetic operations. */

// Type Coercion (Automatically)
console.log('Type Coercion');

// String and Number

let result1 = '5' + 2;
console.log(result1);

let result2 = '5' - 2;
console.log(result2);

let result3 = '5' * 2;
console.log(result3);

let result4 = '5' / 2;
console.log(result4);

// Boolean and Number  // True = 1, False = 0

let result5 = true + 1;
console.log(result5);


let result6 = false * 1;
console.log(result6);

// Coercion occurs in equality checks (==), but not in strict equality checks (===).
// Equality checks

console.log(1 == '1');
console.log(1 === '1');
console.log(1 == 1);

console.log(0 == false);
console.log(0 === false);