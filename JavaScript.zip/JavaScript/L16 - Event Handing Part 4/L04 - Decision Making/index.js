// Decision Making: if, if...else, else if
/* Decision making or control flow in programming is the way we control the execution if code based on certain conditions. This allows the program to make choices and execute different code paths */
/* Types of Decision Making 
1. if
2. if else 
3. else if 
4. switch
5. ternary operator
*/
/*
if(condition){
    //code block
}
if(condition){
    //code block
}
else{
    //code block
}

if(condition){
    //code block
}
else if(condition){
    //code block
}
else{
    //code block
}

switch(value){
    case 1:
        //code block
        break;
        case 2:
            //code block
            break;
            Default:
            //code block
}
(condition)?Expression true:expression false
*/
console.log('Decision Making');

// Example 1: if statement

let temperature = 30;
if (temperature>25){
    console.log('it is hot outside.');
}

// Example 2: if...else statement

if (temperature >= 25){
    console.log('It is hot outside.');
} else {
    console.log('It is cold outside');
}

let isRaining = false;

if (isRaining) {
    console.log('Take an umbrella.');
} else {
    console.log('You do not need an umbrella');
}

// Example 3: else if statement

let time = 14;
if (time < 12) {
    console.log('Good morning!');
} 
else if (time < 18 ) {
    console.log('Good afternoon!');
}
else {
    console.log('Good evening!');
}

// Example 4: Nested if statements
// Variables

let age = 16;
let isWithParent = true;
let hasIdProof = true;

// Decision logic

if(age >= 18){
    if(hasIdProof){
        console.log('You can visit the mall and can able to watch the movie');
    }
    else{
        console.log('You can visit the mall');
    }
}
else{
    if(isWithParent){
        console.log('You can visit the play area.');
    }
    else{
        console.log('You are not allowed the play area.')
    }
}


let day = 1;
if(day === 1){
    console.log('Sunday');
}else if (day === 2){
    console.log('Monday');
}else if(day === 3){
    console.log('Tuesday');
}else if(day === 4){
    console.log('Wednesday');
}else if(day === 5){
    console.log('Thursday');
}else if(day === 6){
    console.log('Friday');
}else if(day === 7){
    console.log('Saturday');
}else{
    console.log('Invalid day');
}

// Switch Statement

switch (day) {
    case 1:
    console.log('Sunday');
    break;
    case 2:
    console.log('Monday');
    break;
    case 3:
    console.log('Tuesday');
    break;
    case 4:
    console.log('Wednesday');
    break;
    case 5:
    console.log('Thursday');
    break;
    case 6:
    console.log('Friday');
    break;
    case 7:
    console.log('Saturday');
    break;
    default:
        console.log('Invalid Day');
}

//Ternary Operator

/*
let isAdmin = true;

if(iAdmin){
    console.log('am admin');
}
else{
    console.log('am user');
}
*/
let isAdmin = true;
let userRole = isAdmin ? 'an admin' : 'an user';
console.log(userRole);

let mark = 25;
let result = 25>= 30? 'pass' :'fail';
console.log(result);