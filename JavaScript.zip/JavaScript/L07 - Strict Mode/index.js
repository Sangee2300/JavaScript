+// Strict Mode

/* Strict mode in JS is a way to opt into a restricted variant of the language. It helps you write cleaner by catching common coding errors and "unsafe" actions, such as asigning to global variables unintentionally. When strict mode is enabled, some silent errors are converted to throw errors, which makes debugging easier. */

'use strict';

let user = 'Abi';

use = 'Anu';

console.log(user);

const interface = 'Car';
const private = 'Jack';