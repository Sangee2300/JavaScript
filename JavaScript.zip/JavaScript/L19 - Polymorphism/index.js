// Renamed person class to Person (capital 'P')
class Person {
    constructor(firstName, lastName, dob, phoneNumber, isEmployed) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.dob = dob;
        this.phoneNumber = phoneNumber;
        this.isEmployed = isEmployed;
    }

    // Method to get details of the person
    getDetails() {
        const age = new Date().getFullYear() - parseInt(this.dob); // dob parsed as a year
        console.log(`${this.firstName} ${this.lastName} is ${age} years old & contact no is ${this.phoneNumber}`);
    }

    // Method to get employment status of the person
    getEmploymentStatus() {
        console.log(`${this.firstName} is ${this.isEmployed ? 'employed' : 'unemployed'}`);
    }
}

// Employee class extending Person
class Employee extends Person {
    constructor(firstName, lastName, dob, phoneNumber, isEmployed, jobTitle, company) {
        super(firstName, lastName, dob, phoneNumber, isEmployed);
        this.jobTitle = jobTitle;
        this.company = company;
    }

    // Overriding the getDetails method
    getDetails() {
        const age = new Date().getFullYear() - parseInt(this.dob); // dob parsed correctly
        console.log(`${this.firstName} ${this.lastName} is ${age} years old & contact no is ${this.phoneNumber}`);
    }

    // Method to get job details of the employee
    getJobDetails() {
        console.log(`${this.firstName} ${this.lastName} works as a ${this.jobTitle} at ${this.company}`);
    }
}

// Creating an Employee instance
let employee1 = new Employee(
    'Arun',
    'Kumar',
    1990, // Assuming dob is year of birth
    9087654321,
    true,
    'Software Developer',
    'Tech Corp'
);

// Calling Employee methods
employee1.getDetails();
employee1.getJobDetails();

// Student class extending Person
class Student extends Person {
    constructor(firstName, lastName, dob, phoneNumber, isEmployed, school, grade) {
        super(firstName, lastName, dob, phoneNumber, isEmployed);
        this.school = school;
        this.grade = grade;
    }

    // Overriding the getDetails method
    getDetails() {
        const age = new Date().getFullYear() - parseInt(this.dob); // dob parsed as year
        console.log(`${this.firstName} ${this.lastName} is ${age} years old, studies in grade ${this.grade} at ${this.school}`);
    }
}

// Creating a Student instance
let student = new Student(
    'Priya',
    'Dharsini',
    1995, // Assuming dob is year of birth
    9249654321,
    false,
    'Sunrise School',
    '10th'
);

// Calling Student method
student.getDetails();
