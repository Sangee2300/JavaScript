// Datatypes
/* Data types are the differnt kinds of information that you can store in variables. Each type of information has a specific purpose and behavior.*/
// Javascript is Dynamic Typing
// Primitive and Object Type

//Primitive Data Types
//1.Number - Represents both integer and floating-point numbers.

let age = 25;
console.log(age);
console.log(typeof age);

let price = 23.43;
console.log(price);
console.log(typeof price);

//2.String - Represents a sequence of characters.

let greeting = "Hi";
console.log(greeting);
console.log(typeof greeting);

//3.Boolean - Represents a logical entity and can have two values: true or false.

let isActive = true;
let hasLicense = false;

console.log(isActive);
console.log(hasLicense);

//4.Undefined - A variable that has been declared but not assigned a value.

let uninitialized;
console.log(uninitialized);

//5.Null - Represents the intentional absence of any object value.

let box = null;
console.log(box);

//6.Symbol - Represents a unique and immutable value, often used as object property keys.

let unique = Symbol('key');
console.log(unique);

//7.BigInt - Represents whole numbers larger than 2^53 - 1 (the largest number JavaScript can reliably represent with the Number type).

let largerNumber = BigInt(90071992547409991); // Using the notation
let largestNumber =  90071992547409992; 
console.log(largerNumber);
console.log(largestNumber);

//Non-Primitive Data Types
//1.Object
/*Represents a collection of properties, each consisting of a key (usually a string) 
and a value (which can be any data type, including another object).*/

let person = {
    name :  "ali ",
    age : 14 ,
    level      : "Student "
};

console.log("I am "+ person.name + "My age is " + person.age + " I am a "+person.level);
console.log(person.name);
console.log(person.age);
console.log(person.level);

//2.Array
//A special type of object used for storing ordered collections of values.

numbers = [ 1, 2, 3, 4, 5 ];
console.log(numbers);

//3.Function
//A special type of object that is callable and can perform an action.
function invite() {
    console.log("You are invited to the project")
    
}
invite();

//4.Date - A built-in object for handling dates and times.

let now = new Date();
console.log(now);