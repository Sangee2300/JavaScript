let person = {
    name: 'Abi',
    age: 21,
    isEmployed: true,
};

console.log(person);
console.log(person.name);
console.log(person.age);
console.log(person.isEmployed);

// Adding a new property

person.city = 'New York';
console.log(person);

// Modifying an existing property

person.age = 25;
console.log(person);

// Object with method

let car = {
    brand: 'Toyota',
    model: 'Camry',
    year: 2023,
    displayInfo: function(){
        return `${this.year} ${this.brand} ${this.model}`;
    },
};

console.log(car);
console.log(car.displayInfo());

// Destructuring assignment

let student = {
    name: 'Abi',
    age: 24,
    course: 'Computer Science',
};
let { name, age, course } = student;

console.log(name);
console.log(age);
console.log(course);

// Nested Complex Objects

let restaurant = {
    name: 'Idli Delights',
    location: 'Chennai',
    owner: {
        name: 'Abi',
        age: 50,
        contact: {
            email: 'abi2679@gmail.com',
            phone: '9876544310',
        },
    },
    menu: [
        { dish: 'Masala Dosa', price: 50, spicy: true },
        { dish: 'Filter coffee', price: 30, spicy: false },
        { dish: 'Pongal', price: 45, spicy: true },
    ],
};

console.log(restaurant);

// Accessing properties of the nested objects

console.log(`Welcome to ${restaurant.name} in ${restaurant.location}`);
console.log(`Owned by ${restaurant.owner.name}, age ${restaurant.owner.age}`);
console.log(`Contact: ${restaurant.owner.contact.email}, ${restaurant.owner.contact.phone}`);

restaurant.menu.forEach((item) => {
    console.log(`${item.dish}: Rs.${item.price} (${item.spicy ? 'Spicy' : 'Not Spicy'})`);
});

// Destructure owner object

let {
    name: OwnerName,
    age: ownerAge,
    contact: { email: ownerEmail, phone: ownerPhone },
} = restaurant.owner;

// Output details about the restaurant

console.log(`Owned by ${OwnerName}, age ${ownerAge}`);
console.log(`Contact: ${ownerEmail}, ${ownerPhone}`);

// Output the menu items using destructuring within forEach

restaurant.menu.forEach(({ dish, price, spicy }) => {
    console.log(`${dish}: Rs.${price} (${spicy ? 'Spicy' : 'Not Spicy'})`);
});
