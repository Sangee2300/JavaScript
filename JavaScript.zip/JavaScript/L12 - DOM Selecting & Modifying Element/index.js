/*
Document Object Model (DOM) manipulation
The following the way to Selecting & Modifying Element in DOM
1.getElementById
2.getElementsByClassName*
3.getElementsByTagName
4.querySelector
5.querySelectorAll
*/


//1.getElementById
// Select a single element based on its unique id attribute.
const heading = document.getElementById('main-heading');

console.log(heading);

// Finding value
console.log(heading.innerHTML); //Outputs the HTML content inside the element
console.log(heading.textContent); //Outputs the text content inside the element

//changing value
heading.innerHTML = 'See, I am from planet earth!';

function changeheading() {
    setTimeout(() =>{
        heading.textContent = 'See, I am from planet mars!';
    }, 2000);
}

changeheading();

//2.getElementsByClassName

const listItems = document.getElementsByClassName('list-item');
console.log(listItems);

console.log(listItems.item(1));
console.log(listItems.item(0).innerHTML);

for(let i=0; i<listItems.length; i++) {
    console.log(listItems.item(i).innerHTML);
}


for(let i=0; i<listItems.length; i++) {
    listItems.item(i).innerHTML = 'Modified Item  $(i+1)';
}
const itemsArray = Array.from(listItems);

itemsArray.forEach((item) => {
    console.log(item.textContent);
});

//3.getElementsByTagName

const contents = document.getElementById('content').getElementsByTagName('p');
console.log(contents);

function contentItemsStyle() {
    contents.item(0).style.color = 'red';
    contents.item(1).style.fontsize = '14px';
    contents.item(2).style.fontWeight = '700';
    contents.item(3).style.backgroundColor = 'pink';
    contents.item(3).style.color = 'white';
 }
 contentItemsStyle();

 function contentStyle(){
    for(let i=0; i<contents.length; i++){
        contents.item(i).style.paddingBottom = '6px';
    }
 }
 contentStyle();


 // Remove element from Dom
 const message = document.getElementById('message');

 setTimeout(() =>{
    message.remove();
 },3000);

 //Adding element to DOM

 const newParagraph = document.createElement('p');
 newParagraph.textContent = 'This is a paragraph added dynamically.';
 newParagraph.style.color = 'green';
 newParagraph.classList.add('new.paragraph');
 const container = document.getElementById('main');
 
/*
appendChild(): Adds a new element as the last child of the parent element.
insertBefore(): Inserts a new element before an existing child element.
insertAdjacentHTML(): Inserts HTML content at a specified position relative to an e
*/

container.appendChild(newParagraph);
container.insertBefore(newParagraph,heading);
container.insertAdjacentHTML('afterbegin','<p>See Me After Main Begin</p>');
container.insertAdjacentHTML('afterend','<p>See Me After Main Begin</p>');
container.insertAdjacentHTML('beforebegin','<p>See Me After Main Begin</p>');
container.insertAdjacentHTML('beforeend','<p>See Me After Main Begin</p>');
('beforeend',
   '<p style="padding-top:20px;">See Me Before Main End</p>'
);

//4.querySelector
/* Selecting elements using QuerySelector (work both class or id more flexibility) */

const subTitle = document.querySelector('#subtitle'); //Id
console.log(subTitle);
console.log(subTitle.textContent);
setTimeout(()=>{
    subTitle.textContent = 'New Subtitle from JS'
}, 4000);


// same way of model change sub and super differenciate
/*const superTitle = document.querySelector('.supertitle'); //class
console.log(superTitle);
console.log(superTitle.textContent);
setTimeout(()=>{
    superTitle.textContent = 'New Supertitle from JS'
}, 4000);
*/
//5.QuerySelectorAll
//Selecting multiple elements using querySelectorAll

const listItemsQuery = document.querySelectorAll('.listItem');
console.log(listItemsQuery);

listItemsQuery.forEach((item, index) => {
item.textContent = 'Modified Item ${index = 2}';
});