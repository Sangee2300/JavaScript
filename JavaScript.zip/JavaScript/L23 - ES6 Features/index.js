/*
Arrow Functions
Variable Declarations
Template Literals
Object Destructuring
Default Parameters
Spread Operator
*/
// ES5 => ES6

//ES5

function add(a,b) {
    return a+b;
} 


//ES6
const add = (a,b) => a+b; 

//ES5
var num1 = 10;

//ES6 
let NUM2 = 20;
const PI = 3.145;

// ES5
var name = 'Alice';
console.log('Hello,' + name + '!');

// ES6
console.log(`Hello, ${name}!`);

//ES5
var userOne = {firstName: "John",lastName:'Joe'};
console.log(userOne.firstName);
console.log(userOne.lastName);

//ES6
var userTwo = {firstName: "Jenne",lastName:'Jar'};
console.log(firstName);
console.log(lastName);

//ES5
function greet(name){
    name = name || 'Guest';
    console.log('Hello'+name+'!');
}
greet('Karthik');

//ES6
function greetUser(name = 'Guest') {
    console.log(`Hello, ${name}!`);
}
greetUser('Alex');

//ES5
let x = [1,2,3];
let y = [4,5,6];
let z = x.concat(y);
console.log(z);

//ES6
letcombined = [...x,...y];
console.log(combined);