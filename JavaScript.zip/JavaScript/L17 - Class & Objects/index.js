/* OBJECT ORIENTEDPROGRAMMING (OOPS)

1. Class & Object (Blueprint)
2. Inheritance (Parent child)
3. Polymorphism (Same method in different form)
4. Encapsulation (Protected) */

let Abi = {
    firstName: 'Abi',
    lastName: 'rami',
    dob: '2002',
    phoneNumber: 1234567890,
    isEmployed: true,
    getDetails: function () {
        const age = new Date().getFullYear() - parseInt(this.dob); // Parse dob as an integer
        console.log(`${this.firstName} ${this.lastName} is ${age} years old & contact no is ${this.phoneNumber}`);
    },
    getEmploymentStatus: function () {
        console.log(`${this.firstName} is ${this.isEmployed ? 'employed' : 'unemployed'}`);
    }
};

console.log(Abi);
Abi.getDetails();
Abi.getEmploymentStatus();

let Anu = {
    firstName: 'Anu',
    lastName: 'ratha',
    dob: '1997',
    phoneNumber: 1234098765,
    isEmployed: false,
    getDetails: function () {
        const age = new Date().getFullYear() - parseInt(this.dob); // Parse dob as an integer
        console.log(`${this.firstName} ${this.lastName} is ${age} years old & contact no is ${this.phoneNumber}`);
    },
    getEmploymentStatus: function () {
        console.log(`${this.firstName} is ${this.isEmployed ? 'employed' : 'unemployed'}`);
    }
};

console.log(Anu);
Anu.getDetails();
Anu.getEmploymentStatus();


class person{
    constructor(firstName,lastName,dob,phoneNumber,isEmployed){
        this.firstName = firstName;
        this.lastName = lastName;
        this.dob = dob;
        this.phoneNumber = phoneNumber;
        this.isEmployed = isEmployed;

    }
    getDetails() {
        const age = new Date().getFullYear() - parseInt(this.dob); // Parse dob as an integer
        console.log(`${this.firstName} ${this.lastName} is ${age} years old & contact no is ${this.phoneNumber}`);
    }
    getEmploymentStatus() {
        console.log(`${this.firstName} is ${this.isEmployed ? 'employed' : 'unemployed'}`);
    }
}

let ant = new person('san','gee',1984,1234098765,true);

ant.getDetails();
ant.getEmploymentStatus();

let ani = new person('star','light',1994,1234548765,false);

ani.getDetails();
ani.getEmploymentStatus();
