// Loops
/* 
In programming, loops are used to execute a block of code repeatedly until
a specific condition is met or for a specified number of times.
They provide a way to perform repetitive tasks efficiently without writing
the same code multiple times.
*/

/* 
Types of Loops
1. For Loop
2. While Loop
3. Do While Loop
 */

// For Loop Example
//using 'let' - block scoped, not accessible outside the lppo

for(let i=0; i<5; i++){
    console.log(`Iteration let ${i}`);
}

//console.log(i);
//using 'var' - function scoped,accessiable outside the loop

for(let j=0; j<5; j++){
    console.log(`Iteration var ${j}`);
}
//console.log(j);

//Looping Backwards

for(let i=5; i>0; i++){
    console.log(`Reverse Iteration ${i}`);
}

//Nested Loop

debugger;
for(let x=1; x<=2; x++){
    console.log(`Outer loop ${x}`);
    
    for(let y=1; y<=3; y++){
    console.log(`Inner loop ${y}`);
    }
}

// While Loop Example

let balance = 10;
console.log(`Balance Amount Before While Loop:${balance}`);

while(balance>0){
    console.log(`Rs.1 is spent, Your current balance amount is ${balance}`);
    balance--;
}

console.log(`Balance Amount After While Loop:${balance}`);

while(balance<50){
    balance += 10;
    console.log(`Rs.10 added to your account, Your current balance amount is ${balance}`);
}

console.log(`Balance amount After Adding Money To your account ${balance}`);

// Do While Loop Example

let num = 0;
do{
    console.log(`Number:${num}`);
    num++;
}
while(num <5);

for(let i=0;i<5;i++){

    if(i===3){
        break; //Terminates the loop when i equals 3
    }
console.log(`Iteration ${i}`);
}

debugger;
for(let i=0;i<5;i++){

    if(i===3){
        break; //Skips thecurrent iteration  when i equals 3
    }
console.log(`Iteration ${i}`);
}
function greet(){
    console.log(`Hello world ${Number}`);
}
greet();

for (let i=0; i<10;i++){
    greet(i);
}


