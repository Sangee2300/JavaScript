console.log("HEllo")

//variable are named storage for data ValidityState. They allow you   to store and manipulate data within your program.

// let, const, var

// Declare and initializze a variable
let x = 10;
console.log(x)

// Declare a variable
let y;
console.log(y);

// Initialize the variable
y = 20;
console.log(y);

// Naming conventions
let userName = 'abi';  //correct camelCase convention
let user_Name = 'anu';  // Underscore is not recommended but valid
console.log(userName); 
console.log(user_name); 
console.log("welcome "  + userName);

/* Incorrect variable names */ 
// Invalid : variable names cannot start with a number
// Invalid : variable names cannot contain symbols
// symbol in variable names 

let $name = 'Anu';
console.log($name);  // only $ this symbol only accepted variable names

//Constants
const PI = 3.145;
console.log(PI); // it is not support a separate initialized and declared

var job = 'developers';
console.log(job);

var job = 'Manager';
console.log(job);

/**
 Scope of variables will on functions and loops
 var: function scoped.
 let: Block scoped.
 const: Block scoped.
 */

 var a = 1;
 var a = 5; //Redeclaration is allowed
 console.log(a);

 let b=2;
 // let b = 10; // Redeclaration is not allowed
 b = 10; // Reassignment is allowed

 console.log(b);

 const c = 3;
 //c = 2; // Reassignment is not allowed
 //const c = 4;  // Redeclaration is not allowed
 console.log(c);
